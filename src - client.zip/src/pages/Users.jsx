// src/pages/Users.jsx
import React, { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { FaFilePdf, FaFileExcel } from "react-icons/fa";
import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";
import * as XLSX from "xlsx";
import BackButton from "../components/BackButton";

const API_BASE =
  (typeof import.meta !== "undefined" && import.meta.env && import.meta.env.VITE_API_URL) ||
  process.env.REACT_APP_API_URL ||
  "http://localhost:4000/api";

// طابِق قيم الـ backend (IT, CycleHead)
const roles = ["All", "Teacher", "Coordinator", "Admin", "IT", "Principal", "CycleHead"];
const grades = ["All", "KG1", "KG2", ...Array.from({ length: 12 }, (_, i) => `Grade ${i + 1}`)];
const statuses = ["All", "Active", "Inactive"];

const Users = () => {
  const [users, setUsers] = useState([]);           // ← من API
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [filters, setFilters] = useState({ role: "All", grade: "All", status: "All" });
  const [selected, setSelected] = useState([]);
  const navigate = useNavigate();

  // جلب من الـ backend
  useEffect(() => {
    let ignore = false;
    async function load() {
      setLoading(true); setError("");
      try {
        // منورّجي الفلاتر محلياً فقط (ما عم نبعت كويري)، فيك لاحقاً تبعتيها كـ querystring إذا بدك
        const res = await fetch(`${API_BASE}/users`);
        const data = await res.json();
        if (!res.ok) throw new Error(data?.message || `Load failed (HTTP ${res.status})`);
        if (!ignore) setUsers(data.users || []);
      } catch (e) {
        if (!ignore) setError(e.message || "Failed to load users");
      } finally {
        if (!ignore) setLoading(false);
      }
    }
    load();
    return () => { ignore = true; };
  }, []);

  const handleFilterChange = (type, value) => {
    setFilters((f) => ({ ...f, [type]: value }));
    setSelected([]);
  };

  const filteredUsers = useMemo(() => {
    return users.filter((u) => {
      const roleMatch = filters.role === "All" || u.role === filters.role;
      const gradeMatch = filters.grade === "All" || u.grade === filters.grade;
      const statusMatch = filters.status === "All" || u.status === filters.status;
      return roleMatch && gradeMatch && statusMatch;
    });
  }, [users, filters]);

  const toggleSelectAll = () => {
    if (selected.length === filteredUsers.length) setSelected([]);
    else setSelected(filteredUsers.map((_, i) => i));
  };

  const toggleSingle = (i) => {
    setSelected((s) => (s.includes(i) ? s.filter((x) => x !== i) : [...s, i]));
  };

  const exportToPDF = () => {
    const dataToExport = selected.length > 0 ? selected.map((i) => filteredUsers[i]) : filteredUsers;
    const doc = new jsPDF();
    doc.text("User List", 14, 15);
    autoTable(doc, {
      startY: 20,
      head: [["#", "Full Name", "Role", "Email", "Phone", "Status"]],
      body: dataToExport.map((u, i) => [i + 1, u.name, u.role, u.email, u.phone, u.status]),
    });
    doc.save("users.pdf");
  };

  const exportToExcel = () => {
    const dataToExport = selected.length > 0 ? selected.map((i) => filteredUsers[i]) : filteredUsers;
    const worksheet = XLSX.utils.json_to_sheet(
      dataToExport.map((u, i) => ({
        "#": i + 1,
        "Full Name": u.name,
        Role: u.role,
        Email: u.email,
        Phone: u.phone,
        Status: u.status,
      }))
    );
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Users");
    XLSX.writeFile(workbook, "users.xlsx");
  };

  // PATCH لتغيير الحالة على السيرفر + تحديث فوري محلي
  const handleStatusChange = async (index, newStatus) => {
    try {
      const user = filteredUsers[index];
      const res = await fetch(`${API_BASE}/users/${user.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: newStatus }), // "Active"/"Inactive"
      });
      const updated = await res.json();
      if (!res.ok) throw new Error(updated?.message || "Update failed");

      // عدّلي بالسجل الأصلي حسب id
      setUsers((prev) => prev.map((u) => (u.id === updated.id ? updated : u)));
    } catch (e) {
      alert(e.message || "Failed to update status");
    }
  };

  return (
    <div className="p-6 bg-[#F9FAFB] min-h-screen text-gray-800">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-semibold">User Management</h2>
        <div className="flex gap-2">
          <button onClick={exportToPDF} className="flex items-center gap-1 border px-3 py-2 rounded text-sm font-medium shadow bg-white hover:bg-gray-100">
            <FaFilePdf /> Export PDF
          </button>
          <button onClick={exportToExcel} className="flex items-center gap-1 border px-3 py-2 rounded text-sm font-medium shadow bg-white hover:bg-gray-100">
            <FaFileExcel /> Export Excel
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div>
          <label className="block text-sm font-medium mb-1">Role</label>
          <select className="bg-gray-200 rounded px-4 py-2 w-full" value={filters.role} onChange={(e) => handleFilterChange("role", e.target.value)}>
            {roles.map((role, i) => <option key={i}>{role}</option>)}
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Grade</label>
          <select className="bg-gray-200 rounded px-4 py-2 w-full" value={filters.grade} onChange={(e) => handleFilterChange("grade", e.target.value)}>
            {grades.map((grade, i) => <option key={i}>{grade}</option>)}
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Status</label>
          <select className="bg-gray-200 rounded px-4 py-2 w-full" value={filters.status} onChange={(e) => handleFilterChange("status", e.target.value)}>
            {statuses.map((s, i) => <option key={i}>{s}</option>)}
          </select>
        </div>
      </div>

      <div className="overflow-auto bg-white shadow rounded-xl">
        <table className="min-w-full text-sm">
          <thead className="bg-gray-50">
            <tr className="text-left border-b">
              <th className="py-3 px-4">
                <input
                  type="checkbox"
                  checked={selected.length === filteredUsers.length && filteredUsers.length > 0}
                  onChange={toggleSelectAll}
                />
              </th>
              <th className="py-3 px-4">#</th>
              <th className="py-3 px-4">Full Name</th>
              <th className="py-3 px-4">Role</th>
              <th className="py-3 px-4">Email</th>
              <th className="py-3 px-4">Phone</th>
              <th className="py-3 px-4">Status</th>
              <th className="py-3 px-4">Actions</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={8} className="px-4 py-8 text-center text-gray-500">Loading...</td></tr>
            ) : error ? (
              <tr><td colSpan={8} className="px-4 py-8 text-center text-red-600">{error}</td></tr>
            ) : filteredUsers.length === 0 ? (
              <tr><td colSpan={8} className="px-4 py-8 text-center text-gray-500">No users</td></tr>
            ) : (
              filteredUsers.map((u, idx) => (
                <tr key={u.id} className="border-b">
                  <td className="px-4 py-3">
                    <input type="checkbox" checked={selected.includes(idx)} onChange={() => toggleSingle(idx)} />
                  </td>
                  <td className="px-4 py-3">{idx + 1}</td>
                  <td className="px-4 py-3">{u.name}</td>
                  <td className="px-4 py-3">{u.role}</td>
                  <td className="px-4 py-3">{u.email}</td>
                  <td className="px-4 py-3">{u.phone}</td>
                  <td className="px-4 py-3">
                    <select
                      className={`rounded px-2 py-1 text-xs ${u.status === "Active" ? "bg-green-100 text-green-700" : "bg-red-100 text-red-600"}`}
                      value={u.status}
                      onChange={(e) => handleStatusChange(idx, e.target.value)}
                    >
                      <option value="Active">Active</option>
                      <option value="Inactive">Inactive</option>
                    </select>
                  </td>
                  <td className="px-4 py-3 space-x-2 whitespace-nowrap">
  <button onClick={() => navigate(`/edit-user/${u.id}`)} className="border border-blue-500 text-blue-500 px-3 py-1 rounded text-xs hover:bg-blue-50">
    Edit
  </button>
  <button
    onClick={() => handleStatusChange(idx, u.status === "Active" ? "Inactive" : "Active")}
    className={`border px-3 py-1 rounded text-xs ${
      u.status === "Active"
        ? "border-red-500 text-red-500 hover:bg-red-50"
        : "border-green-500 text-green-500 hover:bg-green-50"
    }`}
  >
    {u.status === "Active" ? "Deactivate" : "Activate"}
  </button>
  <button onClick={() => navigate(`/reset-password/${u.id}`)} className="border border-gray-400 text-gray-700 px-3 py-1 rounded text-xs hover:bg-gray-100">
    Reset Password
  </button>
  <button
    onClick={() => navigate(`/teacher/${u.id}`)}
    className="border border-purple-500 text-purple-500 px-3 py-1 rounded text-xs hover:bg-purple-50"
  >
    Profile
  </button>
</td>

                </tr>
              ))
            )}
          </tbody>
        </table>
        <BackButton />
      </div>
    </div>
  );
};

export default Users;
