// src/pages/EditUser.jsx
import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

const API_BASE =
  (typeof import.meta !== "undefined" && import.meta.env && import.meta.env.VITE_API_URL) ||
  process.env.REACT_APP_API_URL ||
  "http://localhost:4000/api";

/* ===== helpers (نفس فكرة NewUser) ===== */
const normKey = (k) =>
  String(k || "")
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[^a-z0-9\u0600-\u06FF]+/g, "");

const describeEl = (el) => {
  if (!el) return "";
  const name = el.getAttribute?.("name");
  const id = el.id;
  const aria = el.getAttribute?.("aria-label");
  const ph = el.getAttribute?.("placeholder");
  const lbl =
    el.closest("label")?.textContent ||
    document.querySelector(`label[for="${id}"]`)?.textContent;
  return normKey(name || id || aria || ph || lbl || "");
};

const normalizeContract = (v) => {
  const s = String(v || "").toLowerCase();
  if (!s) return "";
  if (s.includes("full") || s.includes("كامل")) return "Permanent";
  if (s.includes("part") || s.includes("جزئي")) return "Contractual";
  if (s.includes("perman")) return "Permanent";
  if (s.includes("contract")) return "Contractual";
  return v;
};

const collectProfileToFD = (root, fd) => {
  const els = Array.from(root.querySelectorAll("input, select, textarea"));
  const checkedByToken = (token) =>
    els
      .filter((el) => {
        const t = describeEl(el);
        return el.type === "checkbox" && t.includes(token) && el.checked;
      })
      .map((el) => el.value)
      .filter(Boolean);

  const TOK = {
    dob: ["dob", "dateofbirth", "birthdate", "تاريخالميلاد", "ميلاد"],
    place_of_birth: ["placeofbirth", "birthplace", "pob", "مكانالولادة", "محلالولادة"],
    address: ["address", "homeaddress", "addr", "العنوان", "عنوان"],
    gender: ["gender", "sex", "الجنس"],
    phone: [
      "phonenumber",
      "phone",
      "mobile",
      "whatsapp",
      "tel",
      "الهاتف",
      "موبايل",
      "واتساب",
      "رقمالهاتف",
      "رقمالجوال",
    ],
    marital_status: ["maritalstatus", "marriagestatus", "marital", "الحالةالاجتماعية", "الحالهالاجتماعيه"],
    children_info: ["childreninfo", "children", "kids", "child", "الأبناء", "الاولاد", "الأطفال"],
    degree_title: [
      "degreetitle",
      "degree",
      "major",
      "specialization",
      "speciality",
      "specialty",
      "الشهادة",
      "الاختصاص",
      "التخصص",
    ],
    degree_year: ["degreeyear", "graduationyear", "gradyear", "سنةالتخرج", "سنهالتخرج"],
    degree_university: ["degreeuniversity", "university", "college", "institute", "الجامعة", "الجامعه", "الكلية", "المعهد"],
    training_desc: ["trainingdesc", "training", "courses", "workshop", "certificate", "certification", "الدورات", "ورش", "شهادات"],
    contract_type: ["contracttype", "employmenttype", "contractual", "permanent", "نوعالعقد", "متعاقد", "دائم", "مثبت", "مثبّت"],
    salary: ["salary", "wage", "pay", "راتب", "الأجر", "الاجر"],
    subjects: ["subjects", "subjectlist", "المواد", "المادة"],
    grades: ["grades", "gradelist", "الصفوف", "الصف", "المرحلة"],
    experience_years: ["experienceyears", "yearsexperience", "yearsofexperience", "experience", "سنواتالخبرة", "خبرة"],
    job_title: ["jobtitle", "position", "title", "المسمىالوظيفي", "الوظيفة", "المسمى"],
  };

  const pickOne = (tokens) => {
    const toks = tokens.map(normKey);
    const el = els.find((el) => {
      const d = describeEl(el);
      return d && toks.some((t) => d.includes(t));
    });
    if (!el) return "";
    if (el.tagName === "SELECT") return el.value;
    if (el.type === "checkbox" || el.type === "radio") return el.checked ? el.value : "";
    return el.value;
  };

  const dob = pickOne(TOK.dob);
  if (dob) fd.set("dob", String(dob).replace(/\//g, "-"));

  const place_of_birth = pickOne(TOK.place_of_birth);
  if (place_of_birth) fd.set("place_of_birth", place_of_birth);

  const address = pickOne(TOK.address);
  if (address) fd.set("address", address);

  const gender = pickOne(TOK.gender);
  if (gender) fd.set("gender", gender);

  const phone = pickOne(TOK.phone);
  if (phone) fd.set("phone", phone);

  const marital_status = pickOne(TOK.marital_status);
  if (marital_status) fd.set("marital_status", marital_status);

  const children_info = pickOne(TOK.children_info);
  if (children_info) fd.set("children_info", children_info);

  const degree_title = pickOne(TOK.degree_title);
  if (degree_title) fd.set("degree_title", degree_title);

  const degree_year = pickOne(TOK.degree_year);
  if (degree_year) fd.set("degree_year", degree_year);

  const degree_university = pickOne(TOK.degree_university);
  if (degree_university) fd.set("degree_university", degree_university);

  const training_desc = pickOne(TOK.training_desc);
  if (training_desc) fd.set("training_desc", training_desc);

  let contract_type = pickOne(TOK.contract_type);
  if (contract_type) fd.set("contract_type", normalizeContract(contract_type));

  const salary = pickOne(TOK.salary);
  if (salary) fd.set("salary", salary);

  const subjectsArr = checkedByToken("subject");
  if (subjectsArr.length) fd.set("subjects", subjectsArr.join(","));
  const gradesArr = checkedByToken("grade");
  if (gradesArr.length) fd.set("grades", gradesArr.join(","));

  const experience_years = pickOne(TOK.experience_years);
  if (experience_years) fd.set("experience_years", experience_years);

  const job_title = pickOne(TOK.job_title);
  if (job_title) fd.set("job_title", job_title);
};

/* ===== UI options ===== */
const SUBJECT_OPTIONS = [
  "English", "لغة عربية", "Math", "Science", "Biology", "Physics", "Chemistry", "Computer",
  "رياضيات", "جغرافيا", "فلسفة", "تربية", "تاريخ", "اقتصاد", "اجتماع", "دين", "رياضة", "فنون",
];
const GRADE_OPTIONS = ["KG1","KG2","KG3","Grade 1","Grade 2","Grade 3","Grade 4","Grade 5",
  "Grade 6","Grade 7","Grade 8","Grade 9","Grade 10","Grade 11 Scientific","Grade 12 LS","Grade 12 Gs","Grade 12 ES"
];

export default function EditUser() {
  const { id } = useParams();
  const navigate = useNavigate();

  // أساسية (متحكَّم فيها)
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [role, setRole] = useState("Teacher");

  // تعبئة مسبقة للبروفايل (غير متحكَّم فيها - defaultValue/defaultChecked)
  const [prefill, setPrefill] = useState(null); // كل حقول البروفايل
  const [subjectsSet, setSubjectsSet] = useState(new Set());
  const [gradesSet, setGradesSet] = useState(new Set());

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [ok, setOk] = useState("");

  // load current user with full profile
  useEffect(() => {
    let ignore = false;
    (async () => {
      setLoading(true); setError("");
      try {
        const res = await fetch(`${API_BASE}/users/${id}`);
        const data = await res.json();
        if (!res.ok) throw new Error(data?.message || `Load failed (HTTP ${res.status})`);
        if (ignore) return;

        setFullName(data.name || "");
        setEmail(data.email || "");
        setRole(data.role || "Teacher");

        const pf = {
          dob: data.dob || "",
          place_of_birth: data.place_of_birth || "",
          address: data.address || "",
          gender: data.gender || "",
          phone: data.phone || "",
          marital_status: data.marital_status || "",
          children_info: data.children_info || "",
          degree_title: data.degree_title || "",
          degree_year: data.degree_year || "",
          degree_university: data.degree_university || "",
          training_desc: data.training_desc || "",
          contract_type: data.contract_type || "", // Permanent/Contractual
          salary: data.salary || "",
          experience_years: data.experience_years || "",
          job_title: data.job_title || "",
        };
        setPrefill(pf);

        setSubjectsSet(new Set((data.subjects || "").split(",").map(s => s.trim()).filter(Boolean)));
        setGradesSet(new Set((data.grades || "").split(",").map(s => s.trim()).filter(Boolean)));
      } catch (e) {
        setError(e.message || "Failed to load user");
      } finally {
        setLoading(false);
      }
    })();
    return () => { ignore = true; };
  }, [id]);

  const toggleSet = (setter, currentSet, v) => {
    const ns = new Set(currentSet);
    if (ns.has(v)) ns.delete(v); else ns.add(v);
    setter(ns);
  };

  const handleSave = async (e) => {
    e?.preventDefault?.();
    setError(""); setOk("");

    if (!fullName.trim()) { setError("Full name is required."); return; }

    setSaving(true);
    try {
      // جهّز FormData من DOM (نفس فكرة NewUser) + الأساسيات
      const root = document.getElementById("root") || document.body;
      const fd = new FormData();
      fd.set("full_name", fullName.trim());
      if (email) fd.set("email", email.trim());
      if (role) fd.set("role", role);

      // subjects/grades من state (لأننا عم نتحكم بالتأشير)
      if (subjectsSet.size) fd.set("subjects", Array.from(subjectsSet).join(","));
      if (gradesSet.size) fd.set("grades", Array.from(gradesSet).join(","));

      // الباقي من DOM
      collectProfileToFD(root, fd);

      // حوّل ل JSON payload
      const payload = {};
      for (const [k, v] of fd.entries()) payload[k] = v;

      const res = await fetch(`${API_BASE}/users/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const updated = await res.json();
      if (!res.ok) throw new Error(updated?.message || `Save failed (HTTP ${res.status})`);

      setOk("Saved!");
      setTimeout(() => navigate("/users"), 700);
    } catch (e) {
      setError(e.message || "Save failed");
    } finally {
      setSaving(false);
    }
  };

  // خرّجي قيمة select الـ Employment بالنص الموازي
  const employmentLabelFromType = (t) =>
    t === "Permanent" ? "Full-time" : t === "Contractual" ? "Part-time" : "";

  if (loading) return <div className="p-6">Loading…</div>;

  return (
    <div className="p-6 md:p-8 bg-blue min-h-screen text-gray-800">
      <div className="bg-blue p-6 md:p-8 rounded-xl shadow">
        <div className="mb-6 border-b pb-4 flex justify-between items-center">
          <h2 className="text-2xl font-bold text-gray-800">Edit User</h2>
          <button onClick={() => navigate(-1)} className="border px-3 py-2 bg-blue-100 rounded text-sm  hover:bg-red-100">
            Back
          </button>
        </div>

        {error && <div className="mb-4 rounded-md bg-red-50 border border-red-200 px-4 py-3 text-sm text-red-700">{error}</div>}
        {ok && <div className="mb-4 rounded-md bg-green-50 border border-green-200 px-4 py-3 text-sm text-green-800">{ok}</div>}

        {/* Basic Identity */}
        <section className="mb-8">
          <h3 className="text-lg font-semibold text-gray-700 mb-4">Basic Identity</h3>
          <div className="grid md:grid-cols-2 gap-4">
            <input
              placeholder="Full Name"
              className="w-full border px-4 py-2 rounded"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
            />
            <input type="date" className="w-full border px-4 py-2 rounded" defaultValue={prefill?.dob || ""} />
            <input placeholder="Place of Birth" className="w-full border px-4 py-2 rounded" defaultValue={prefill?.place_of_birth || ""} />
            <select className="w-full border px-4 py-2 rounded" defaultValue={prefill?.gender || ""}>
              <option value="">Select Gender</option>
              <option>Male</option>
              <option>Female</option>
              <option>Other</option>
            </select>
            <div className="flex items-center justify-center border rounded-md h-12">
              <span className="text-gray-400 text-sm">+</span>
            </div>
            <select
              className="w-full border px-4 py-2 rounded"
              value={role}
              onChange={(e) => setRole(e.target.value)}
            >
              <option>Teacher</option>
              <option>Coordinator</option>
              <option>Admin</option>
              <option>IT</option>
              <option>Principal</option>
              <option>CycleHead</option>
            </select>
          </div>
        </section>

        {/* Contact */}
        <section className="mb-8">
          <h3 className="text-lg font-semibold text-gray-700 mb-4">Contact Details</h3>
          <div className="grid md:grid-cols-2 gap-4">
            <input placeholder="Home Address" className="w-full border px-4 py-2 rounded col-span-2" defaultValue={prefill?.address || ""} />
            <input placeholder="Phone Number" className="w-full border px-4 py-2 rounded" defaultValue={prefill?.phone || ""} />
            <input
              placeholder="Email Address"
              className="w-full border px-4 py-2 rounded"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
        </section>

        {/* Social */}
        <section className="mb-8">
          <h3 className="text-lg font-semibold text-gray-700 mb-4">Social Status</h3>
          <input placeholder="Marital Status" className="w-full border px-4 py-2 rounded" defaultValue={prefill?.marital_status || ""} />
        </section>

        {/* Education */}
        <section className="mb-8">
          <h3 className="text-lg font-semibold text-gray-700 mb-4">Education Background</h3>
          <div className="grid md:grid-cols-2 gap-4">
            <select className="w-full border px-4 py-2 rounded" defaultValue={prefill?.degree_title || ""}>
              <option value="">Select Degree Type</option>
              <option>Bachelor</option>
              <option>Master</option>
              <option>PhD</option>
            </select>
            <input placeholder="Specialization" className="w-full border px-4 py-2 rounded" defaultValue={prefill?.job_title || ""} />
            <input type="number" placeholder="Graduation Year" className="w-full border px-4 py-2 rounded" defaultValue={prefill?.degree_year || ""} />
            <input placeholder="University / Institute" className="w-full border px-4 py-2 rounded" defaultValue={prefill?.degree_university || ""} />
            <input type="file" className="w-full border px-4 py-2 rounded col-span-2" />
          </div>
        </section>

        {/* Training & Professional */}
        <section className="mb-8">
          <h3 className="text-lg font-semibold text-gray-700 mb-4">Training & Professional Status</h3>

          {/* (الـ courses ملفات وصف… تركناها UI فقط) */}

          <div className="grid md:grid-cols-2 gap-4">
            <select className="w-full border px-4 py-2 rounded" defaultValue={employmentLabelFromType(prefill?.contract_type || "")}>
              <option value="">Select Employment Type</option>
              <option>Full-time</option>
              <option>Part-time</option>
            </select>
            <input placeholder="Monthly Salary" className="w-full border px-4 py-2 rounded" defaultValue={prefill?.salary || ""} />
            <input placeholder="Years of Experience" className="w-full border px-4 py-2 rounded col-span-2" defaultValue={prefill?.experience_years || ""} />
            <input placeholder="Training / Courses / Workshops" className="w-full border px-4 py-2 rounded col-span-2" defaultValue={prefill?.training_desc || ""} />
          </div>

          {/* Subjects */}
          <div className="mt-6">
            <p className="font-medium text-sm mb-2">Subjects Taught</p>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
              {SUBJECT_OPTIONS.map((label) => {
                const active = subjectsSet.has(label);
                return (
                  <label key={label} className="inline-flex w-full cursor-pointer">
                    <input
                      type="checkbox"
                      name="subjects"
                      value={label}
                      className="peer sr-only"
                      checked={active}
                      onChange={() => toggleSet(setSubjectsSet, subjectsSet, label)}
                    />
                    <span className={`w-full select-none rounded-full border px-3 py-1.5 text-sm
                      ${active ? "border-blue-600 bg-blue-600/10 text-blue-700" : "text-gray-700 hover:bg-gray-50"}`}>
                      {label}
                    </span>
                  </label>
                );
              })}
            </div>
          </div>

          {/* Grades */}
          <div className="mt-6">
            <p className="font-medium text-sm mb-2">Grade Levels Taught</p>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
              {GRADE_OPTIONS.map((g) => {
                const active = gradesSet.has(g);
                return (
                  <label key={g} className="inline-flex w-full cursor-pointer">
                    <input
                      type="checkbox"
                      name="grades"
                      value={g}
                      className="peer sr-only"
                      checked={active}
                      onChange={() => toggleSet(setGradesSet, gradesSet, g)}
                    />
                    <span className={`w-full select-none rounded-full border px-3 py-1.5 text-sm
                      ${active ? "border-blue-600 bg-blue-600/10 text-blue-700" : "text-gray-700 hover:bg-gray-50"}`}>
                      {g}
                    </span>
                  </label>
                );
              })}
            </div>
          </div>
        </section>

        <div className="mt-6 text-end">
          <button
            onClick={handleSave}
            disabled={saving}
            className="bg-blue-600 text-white px-6 py-2 rounded-md shadow hover:bg-blue-700 transition disabled:opacity-70"
          >
            {saving ? "Saving..." : "Save Changes"}
          </button>
        </div>
      </div>
    </div>
  );
}
