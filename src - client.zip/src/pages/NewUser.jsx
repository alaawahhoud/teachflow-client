// src/pages/NewUser.jsx
import React, { useState } from "react";

// فوق الملف (بعد الـ imports)
const API_BASE =
  (typeof import.meta !== "undefined" && import.meta.env && import.meta.env.VITE_API_URL) ||
  process.env.REACT_APP_API_URL ||
  "http://localhost:4000/api";
// ---- helpers (لا تغيّري الستايل بالمكوّنات) ----

// تطبيع للمفاتيح (يدعم عربي) لنتعرّف على معنى الحقل حتى بدون name
const normKey = (k) =>
  String(k || "")
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[^a-z0-9\u0600-\u06FF]+/g, "");

// استخرج نص يعبّر عن الحقل (name || id || aria-label || placeholder || label text)
const describeEl = (el) => {
  if (!el) return "";
  const name = el.getAttribute?.("name");
  const id = el.id;
  const aria = el.getAttribute?.("aria-label");
  const ph = el.getAttribute?.("placeholder");
  const lbl = el.closest("label")?.textContent || document.querySelector(`label[for="${id}"]`)?.textContent;
  return normKey(name || id || aria || ph || lbl || "");
};

// حوّل “دوام كامل/جزئي” → Contractual/Permanent إلخ
const normalizeContract = (v) => {
  const s = String(v || "").toLowerCase();
  if (!s) return "";
  if (s.includes("full") || s.includes("كامل")) return "Permanent";
  if (s.includes("part") || s.includes("جزئي")) return "Contractual";
  if (s.includes("perman")) return "Permanent";
  if (s.includes("contract")) return "Contractual";
  return v;
};

const collectProfileToFD = (root, fd) => {
  const els = Array.from(root.querySelectorAll("input, select, textarea"));
  const checkedByToken = (token) =>
    els
      .filter((el) => {
        const t = describeEl(el);
        return el.type === "checkbox" && t.includes(token) && el.checked;
      })
      .map((el) => el.value)
      .filter(Boolean);

  const TOK = {
    dob: ["dob", "dateofbirth", "birthdate", "تاريخالميلاد", "ميلاد"],
    place_of_birth: ["placeofbirth", "birthplace", "pob", "مكانالولادة", "محلالولادة"],
    address: ["address", "homeaddress", "addr", "العنوان", "عنوان"],
    gender: ["gender", "sex", "الجنس"],
    phone: ["phonenumber", "phone", "mobile", "whatsapp", "tel", "الهاتف", "موبايل", "واتساب", "رقمالهاتف", "رقمالجوال"],
    marital_status: ["maritalstatus", "marriagestatus", "marital", "الحالةالاجتماعية", "الحالهالاجتماعيه"],
    children_info: ["childreninfo", "children", "kids", "child", "الأبناء", "الاولاد", "الأطفال"],
    degree_title: ["degreetitle", "degree", "major", "specialization", "speciality", "specialty", "الشهادة", "الاختصاص", "التخصص"],
    degree_year: ["degreeyear", "graduationyear", "gradyear", "سنةالتخرج", "سنهالتخرج"],
    degree_university: ["degreeuniversity", "university", "college", "institute", "الجامعة", "الجامعه", "الكلية", "المعهد"],
    training_desc: ["trainingdesc", "training", "courses", "workshop", "certificate", "certification", "الدورات", "ورش", "شهادات"],
    contract_type: ["contracttype", "employmenttype", "contractual", "permanent", "نوعالعقد", "متعاقد", "دائم", "مثبت", "مثبّت"],
    salary: ["salary", "wage", "pay", "راتب", "الأجر", "الاجر"],
    subjects: ["subjects", "subjectlist", "المواد", "المادة"],
    grades: ["grades", "gradelist", "الصفوف", "الصف", "المرحلة"],
    experience_years: ["experienceyears", "yearsexperience", "yearsofexperience", "experience", "سنواتالخبرة", "خبرة"],
    job_title: ["jobtitle", "position", "title", "المسمىالوظيفي", "الوظيفة", "المسمى"],
  };

  // helper عام: أول input وصفه يحتوي أي توكن
  const pickOne = (tokens) => {
    const toks = tokens.map(normKey);
    const el = els.find((el) => {
      const d = describeEl(el);
      return d && toks.some((t) => d.includes(t));
    });
    if (!el) return "";
    if (el.tagName === "SELECT") return el.value;
    if (el.type === "checkbox" || el.type === "radio") return el.checked ? el.value : "";
    return el.value;
  };

  const dob = pickOne(TOK.dob);
  if (dob) fd.set("dob", String(dob).replace(/\//g, "-"));

  const place_of_birth = pickOne(TOK.place_of_birth);
  if (place_of_birth) fd.set("place_of_birth", place_of_birth);

  const address = pickOne(TOK.address);
  if (address) fd.set("address", address);

  const gender = pickOne(TOK.gender);
  if (gender) fd.set("gender", gender);

  const phone = pickOne(TOK.phone);
  if (phone) fd.set("phone", phone);

  const marital_status = pickOne(TOK.marital_status);
  if (marital_status) fd.set("marital_status", marital_status);

  const children_info = pickOne(TOK.children_info);
  if (children_info) fd.set("children_info", children_info);

  const degree_title = pickOne(TOK.degree_title);
  if (degree_title) fd.set("degree_title", degree_title);

  const degree_year = pickOne(TOK.degree_year);
  if (degree_year) fd.set("degree_year", degree_year);

  const degree_university = pickOne(TOK.degree_university);
  if (degree_university) fd.set("degree_university", degree_university);

  const training_desc = pickOne(TOK.training_desc);
  if (training_desc) fd.set("training_desc", training_desc);

  let contract_type = pickOne(TOK.contract_type);
  if (contract_type) fd.set("contract_type", normalizeContract(contract_type));

  const salary = pickOne(TOK.salary);
  if (salary) fd.set("salary", salary);

  // subjects / grades (checkbox groups) → CSV
  const subjectsArr = checkedByToken("subject");
  if (subjectsArr.length) fd.set("subjects", subjectsArr.join(","));
  const gradesArr = checkedByToken("grade");
  if (gradesArr.length) fd.set("grades", gradesArr.join(","));

  const experience_years = pickOne(TOK.experience_years);
  if (experience_years) fd.set("experience_years", experience_years);

  const job_title = pickOne(TOK.job_title);
  if (job_title) fd.set("job_title", job_title);
};

const NewUser = () => {
  // minimal fields required for account creation
  const [fullName, setFullName] = useState(""); 
  const [email, setEmail] = useState("");
  const [role, setRole] = useState("Teacher");
  const [password, setPassword] = useState(""); // optional; if empty, server will use "1234"

  // ui state
  const [saving, setSaving] = useState(false);
  const [successInfo, setSuccessInfo] = useState(null);
  const [errorMsg, setErrorMsg] = useState("");

  // (keeping your existing courses UI as-is)
  const [courses, setCourses] = useState([{ file: "", description: "" }]);
  const addCourse = () => setCourses([...courses, { file: "", description: "" }]);

const handleSave = async (e) => {
  e?.preventDefault?.();
  setErrorMsg("");
  setSuccessInfo(null);

  if (!fullName || !fullName.trim()) {
    setErrorMsg("Full name is required.");
    return;
  }

  setSaving(true);
  try {
    // جهّز FormData
    const root = document.getElementById("root") || document.body; // أو أي container جامع للفورم
    const fd = new FormData();

    // الحقول الأساسية من الstate (وهي أكيد موجودة عندك)
    fd.set("full_name", fullName.trim());
    if (email) fd.set("email", email.trim());
    if (role) fd.set("role", role);

    // نجمع تلقائيًا كل حقول البروفايل (من DOM)
    collectProfileToFD(root, fd);

    // ملاحظة: السيرفر عندك بيولّد باسورد 6 محارف تلقائي، فما رح نبعت password
for (const [k, v] of fd.entries()) {
  console.log("FD", k, "=", v);
}

    const res = await fetch(`${API_BASE}/users`, {
      method: "POST",
      body: fd, // لا تضيف Content-Type يدويًا
    });

    let data = {};
    try { data = await res.json(); } catch {}

    if (!res.ok) {
      throw new Error(data?.message || `Save failed (HTTP ${res.status})`);
    }

    setSuccessInfo({
      id: data?.user?.id,
      username: data?.user?.username,
      tempPassword: data?.temp_password, // الباسورد المؤقّت من السيرفر
      role: data?.user?.role,
    });

    // نظّفي الحقول المتحكّم فيها إذا بتحبي
    // setFullName(""); setEmail(""); setRole("Teacher");
  } catch (err) {
    setErrorMsg(err.message || "Save failed");
  } finally {
    setSaving(false);
  }
};
const SUBJECT_OPTIONS = [
  "English",
  "لغة عربية",
  "Math",
  "Science",
  "Biology",
  "Physics",
  "Chemistry",
  "Computer",
  "رياضيات",
  "جغرافيا",
  "فلسفة",
  "تربية",
  "تاريخ",
  "اقتصاد",
  "اجتماع",
  "دين",
  "رياضة",
  "فنون",
];
 const GRADE_OPTIONS = ["KG1","KG2","KG3","Grade 1","Grade 2","Grade 3","Grade 4","Grade 5",
  "Grade 6","Grade 7","Grade 8", "Grade 9", "Grade 10","Grade 11 Scientific" , "Grade 12 LS" , "Grade 12 Gs", "Grade 12 ES"
 ];
  return (
    <div className="p-6 md:p-8 bg-[#F9FAFB] min-h-screen text-gray-800">
      <div className="bg-white p-6 md:p-8 rounded-xl shadow">
        <div className="mb-6 border-b pb-4 flex justify-between items-center">
          <h2 className="text-2xl font-bold text-gray-800">Teacher Information Form</h2>
          <span className="text-blue-600 font-semibold">TeachFlow</span>
        </div>

        {/* Alerts */}
        {errorMsg && (
          <div className="mb-4 rounded-md bg-red-50 border border-red-200 px-4 py-3 text-sm text-red-700">
            {errorMsg}
          </div>
        )}
        {successInfo && (
          <div className="mb-4 rounded-md bg-green-50 border border-green-200 px-4 py-3 text-sm text-green-800">
            <p className="font-semibold">User created successfully ✅</p>
            <p>Username: <span className="font-mono">{successInfo.username}</span></p>
            {successInfo.tempPassword && (
              <p>Temporary password: <span className="font-mono">{successInfo.tempPassword}</span></p>
            )}
            <p>Role: {successInfo.role}</p>
          </div>
        )}

        {/* Section Title */}
        <section className="mb-8">
          <h3 className="text-lg font-semibold text-gray-700 mb-4">Basic Identity</h3>
          <div className="grid md:grid-cols-2 gap-4">
            <input
              placeholder="Full Name"
              className="w-full border px-4 py-2 rounded"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
            />
            <input type="date" className="w-full border px-4 py-2 rounded" />
            <input placeholder="Place of Birth" className="w-full border px-4 py-2 rounded" />
            <select
              className="w-full border px-4 py-2 rounded"
              defaultValue="Select Gender"
            >
              <option disabled>Select Gender</option>
              <option>Male</option>
              <option>Female</option>
            </select>
            <div className="flex items-center justify-center border rounded-md h-12">
              <span className="text-gray-400 text-sm">+</span>
            </div>
            <select
              className="w-full border px-4 py-2 rounded"
              value={role}
              onChange={(e) => setRole(e.target.value)}
            >
              <option>Teacher</option>
              <option>Coordinator</option>
              <option>Admin</option>
              <option>IT Support</option>
              <option>Principal</option>
              <option>Cycle Head</option>
            </select>
          </div>
        </section>

        <section className="mb-8">
          <h3 className="text-lg font-semibold text-gray-700 mb-4">Contact Details</h3>
          <div className="grid md:grid-cols-2 gap-4">
            <input placeholder="Home Address" className="w-full border px-4 py-2 rounded col-span-2" />
            <input placeholder="Phone Number" className="w-full border px-4 py-2 rounded" />
            <input
              placeholder="Email Address"
              className="w-full border px-4 py-2 rounded"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
        </section>

        <section className="mb-8">
          <h3 className="text-lg font-semibold text-gray-700 mb-4">Social Status</h3>
          <input placeholder="Marital Status" className="w-full border px-4 py-2 rounded" />
        </section>

        <section className="mb-8">
          <h3 className="text-lg font-semibold text-gray-700 mb-4">Education Background</h3>
          <div className="grid md:grid-cols-2 gap-4">
            <select className="w-full border px-4 py-2 rounded">
              <option>Select Degree Type</option>
              <option>Bachelor</option>
              <option>Master</option>
              <option>PhD</option>
            </select>
            <input placeholder="Specialization" className="w-full border px-4 py-2 rounded" />
            <input type="number" placeholder="Graduation Year" className="w-full border px-4 py-2 rounded" />
            <input placeholder="University / Institute" className="w-full border px-4 py-2 rounded" />
            <input type="file" className="w-full border px-4 py-2 rounded col-span-2" />
          </div>
        </section>

        <section className="mb-8">
          <h3 className="text-lg font-semibold text-gray-700 mb-4">Training & Professional Status</h3>

          {courses.map((_, idx) => (
            <div key={idx} className="grid md:grid-cols-2 gap-4 mb-4">
              <input type="file" className="w-full border px-4 py-2 rounded" />
              <input placeholder="Description" className="w-full border px-4 py-2 rounded" />
            </div>
          ))}

          <button
            onClick={addCourse}
            className="text-sm bg-blue-100 text-blue-600 px-4 py-2 rounded hover:bg-blue-200 mb-6"
            type="button"
          >
            + Add Course
          </button>

          <div className="grid md:grid-cols-2 gap-4">
            <select className="w-full border px-4 py-2 rounded">
              <option>Select Employment Type</option>
              <option>Full-time</option>
              <option>Part-time</option>
            </select>
            <input placeholder="Monthly Salary" className="w-full border px-4 py-2 rounded" />
            <input placeholder="Years of Experience" className="w-full border px-4 py-2 rounded col-span-2" />
          </div>

          <div className="mt-6">
            
  <p className="font-medium text-sm mb-2">Subjects Taught</p>
<div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
    {SUBJECT_OPTIONS.map((label) => (
      <label key={label} className="inline-flex w-full cursor-pointer">
        <input
          type="checkbox"
          name="subjects"
          value={label}
          className="peer sr-only"
        />
        <span className="w-full select-none rounded-full border px-3 py-1.5 text-sm text-gray-700
                         hover:bg-gray-50
                         peer-checked:border-blue-600 peer-checked:bg-blue-600/10 peer-checked:text-blue-700
                         peer-focus-visible:ring-2 peer-focus-visible:ring-blue-500/40">
          {label}
        </span>
      </label>
    ))}
  </div>
</div>
<div className="mt-6">
  <p className="font-medium text-sm mb-2">Grade Levels Taught</p>

  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
    {GRADE_OPTIONS.map((g) => (
      <label key={g} className="inline-flex w-full cursor-pointer">
        <input
          type="checkbox"
          name="grades"
          value={g}
          className="peer sr-only"
        />
        <span className="w-full select-none rounded-full border px-3 py-1.5 text-sm text-gray-700
                         hover:bg-gray-50
                         peer-checked:border-blue-600 peer-checked:bg-blue-600/10 peer-checked:text-blue-700
                         peer-focus-visible:ring-2 peer-focus-visible:ring-blue-500/40">
          {g}
        </span>
      </label>
    ))}
  </div>
</div>

        </section>

        <div className="mt-6 text-end">
          <button
            onClick={handleSave}
            disabled={saving}
            className="bg-blue-600 text-white px-6 py-2 rounded-md shadow hover:bg-blue-700 transition disabled:opacity-70"
          >
            {saving ? "Saving..." : "Save Changes"}
          </button>
        </div>
      </div>
    </div>
  );
};

export default NewUser;
