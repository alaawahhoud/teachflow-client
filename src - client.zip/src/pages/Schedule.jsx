// src/pages/Schedule.jsx
import React, { useState } from "react";
import jsPDF from "jspdf";
import "jspdf-autotable";

const Schedule = () => {
  const initialSchedule = {
    Monday: [
      { subject: "Math", teacher: "Mr. Omar", room: "R201" },
      { subject: "English", teacher: "Ms. Sarah", room: "R105" },
      { subject: "Science", teacher: "Dr. Ahmed", room: "Lab1" },
      { subject: "History", teacher: "Mr. Hassan", room: "R302" },
      { subject: "Arabic", teacher: "Ms. Fatima", room: "R204" },
      { subject: "French", teacher: "Mme. Claire", room: "R108" },
      { subject: "PE", teacher: "Coach Ali", room: "Gym" },
    ],
    Tuesday: [
      { subject: "Science", teacher: "Dr. Ahmed", room: "Lab1" },
      { subject: "Math", teacher: "Mr. Omar", room: "R201" },
      { subject: "Arabic", teacher: "Ms. Fatima", room: "R204" },
      { subject: "English", teacher: "Ms. Sarah", room: "R105" },
      { subject: "French", teacher: "Mme. Claire", room: "R108" },
      { subject: "History", teacher: "Mr. Hassan", room: "R302" },
      { subject: "PE", teacher: "Coach Ali", room: "Gym" },
    ],
    Wednesday: [
      { subject: "English", teacher: "Ms. Sarah", room: "R105" },
      { subject: "Science", teacher: "Dr. Ahmed", room: "Lab1" },
      { subject: "Math", teacher: "Mr. Omar", room: "R201" },
      { subject: "PE", teacher: "Coach Ali", room: "Gym" },
      { subject: "History", teacher: "Mr. Hassan", room: "R302" },
      { subject: "Arabic", teacher: "Ms. Fatima", room: "R204" },
      { subject: "French", teacher: "Mme. Claire", room: "R108" },
    ],
    Thursday: [
      { subject: "History", teacher: "Mr. Hassan", room: "R302" },
      { subject: "Math", teacher: "Mr. Omar", room: "R201" },
      { subject: "French", teacher: "Mme. Claire", room: "R108" },
      { subject: "Science", teacher: "Dr. Ahmed", room: "Lab1" },
      { subject: "English", teacher: "Ms. Sarah", room: "R105" },
      { subject: "PE", teacher: "Coach Ali", room: "Gym" },
      { subject: "Arabic", teacher: "Ms. Fatima", room: "R204" },
    ],
    Friday: [
      { subject: "Arabic", teacher: "Ms. Fatima", room: "R204" },
      { subject: "History", teacher: "Mr. Hassan", room: "R302" },
      { subject: "English", teacher: "Ms. Sarah", room: "R105" },
      { subject: "Math", teacher: "Mr. Omar", room: "R201" },
      { subject: "Science", teacher: "Dr. Ahmed", room: "Lab1" },
      { subject: "French", teacher: "Mme. Claire", room: "R108" },
      { subject: "PE", teacher: "Coach Ali", room: "Gym" },
    ],
  };

  const subjectColors = {
    Math: "bg-blue-100",
    English: "bg-pink-100",
    Science: "bg-green-100",
    History: "bg-yellow-100",
    Arabic: "bg-purple-100",
    French: "bg-indigo-100",
    PE: "bg-gray-100",
  };

  const subjects = Object.keys(subjectColors);
  const periods = ["1st", "2nd", "3rd", "4th", "5th", "6th", "7th"];
  const days = Object.keys(initialSchedule);

  const [scheduleData, setScheduleData] = useState(initialSchedule);
  const [isEditing, setIsEditing] = useState(false);
  const [selectedGrade, setSelectedGrade] = useState("All");
  const [selectedTeacher, setSelectedTeacher] = useState("All");
  const [selectedSubject, setSelectedSubject] = useState("All");

  const handleSubjectChange = (day, periodIndex, newSubject) => {
    const updated = { ...scheduleData };
    updated[day][periodIndex].subject = newSubject;
    setScheduleData(updated);
  };

  const filteredSchedule = {};
  for (const day of days) {
    filteredSchedule[day] = scheduleData[day].map((session) => {
      const matchTeacher = selectedTeacher === "All" || session.teacher === selectedTeacher;
      const matchSubject = selectedSubject === "All" || session.subject === selectedSubject;
      return matchTeacher && matchSubject ? session : null;
    });
  }

const exportToPDF = () => {
  const doc = new jsPDF();
  const tableColumn = ["Period", ...days];
  const tableRows = [];

  periods.forEach((label, index) => {
    const row = [`${label} Period`];
    days.forEach((day) => {
      const session = filteredSchedule[day][index];
      const value = session
        ? `${session.subject}\n${session.teacher}\n${session.room}`
        : "—";
      row.push(value);
    });
    tableRows.push(row);
  });

  doc.autoTable({
    head: [tableColumn],
    body: tableRows,
    startY: 20,
    styles: { fontSize: 8 },
    theme: "grid",
  });

  doc.save("filtered_schedule.pdf");
};

  return (
    <div className="p-6 bg-[#F9FAFB] min-h-screen text-gray-800">
      <div className="flex flex-wrap justify-between items-center mb-6 gap-4">
        <div>
          <h2 className="text-2xl font-bold">Weekly Class Schedule</h2>
          <p className="text-sm text-gray-500">
            {new Date().toLocaleDateString("en-US", {
              weekday: "long",
              year: "numeric",
              month: "long",
              day: "numeric",
            })}
          </p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={exportToPDF}
            className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600 transition"
          >
            📄 Export as PDF
          </button>
          <button
            onClick={() => setIsEditing(!isEditing)}
            className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition"
          >
            {isEditing ? "✅ Done Editing" : "✏️ Edit Schedule"}
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <select
          className="bg-white border border-gray-300 rounded-lg px-4 py-2 shadow-sm"
          value={selectedGrade}
          onChange={(e) => setSelectedGrade(e.target.value)}
        >
          <option value="All">All Grades</option>
          {["Grade 9A", "Grade 9B", "Grade 10A", "Grade 10C"].map((grade) => (
            <option key={grade}>{grade}</option>
          ))}
        </select>

        <select
          className="bg-white border border-gray-300 rounded-lg px-4 py-2 shadow-sm"
          value={selectedTeacher}
          onChange={(e) => setSelectedTeacher(e.target.value)}
        >
          <option value="All">All Teachers</option>
          {["Mr. Omar", "Ms. Sarah", "Dr. Ahmed", "Mr. Hassan", "Ms. Fatima", "Mme. Claire", "Coach Ali"].map((teacher) => (
            <option key={teacher}>{teacher}</option>
          ))}
        </select>

        <select
          className="bg-white border border-gray-300 rounded-lg px-4 py-2 shadow-sm"
          value={selectedSubject}
          onChange={(e) => setSelectedSubject(e.target.value)}
        >
          <option value="All">All Subjects</option>
          {subjects.map((subject) => (
            <option key={subject}>{subject}</option>
          ))}
        </select>

        <div className="bg-gray-100 rounded-lg px-4 py-2 flex items-center justify-center text-sm text-gray-600">
          📅 {new Date().toLocaleDateString()}
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto rounded-xl shadow bg-white">
        <table className="w-full text-sm text-left min-w-[800px]">
          <thead>
            <tr className="bg-gray-100 border-b text-gray-700">
              <th className="px-4 py-3">Period</th>
              {days.map((day) => (
                <th key={day} className="px-4 py-3 text-center">{day}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {periods.map((label, periodIndex) => (
              <tr key={periodIndex} className="border-b hover:bg-gray-50">
                <td className="px-4 py-3 font-semibold text-gray-600">
                  {label} Period
                </td>
                {days.map((day) => {
                  const session = filteredSchedule[day][periodIndex];
                  const color = subjectColors[session?.subject] || "bg-white";

                  return (
                    <td key={day} className={`px-4 py-3 ${color}`}>
                      {isEditing && session ? (
                        <select
                          value={session.subject}
                          onChange={(e) =>
                            handleSubjectChange(day, periodIndex, e.target.value)
                          }
                          className="w-full rounded border-gray-300 p-1 text-sm"
                        >
                          {subjects.map((subj) => (
                            <option key={subj} value={subj}>
                              {subj}
                            </option>
                          ))}
                        </select>
                      ) : session ? (
                        <>
                          <p className="font-semibold text-sm">{session.subject}</p>
                          <p className="text-xs text-gray-700">{session.teacher}</p>
                          <p className="text-xs text-gray-500">{session.room}</p>
                        </>
                      ) : (
                        <p className="text-xs text-gray-400 italic text-center">—</p>
                      )}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Schedule;
