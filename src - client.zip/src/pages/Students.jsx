// src/pages/Students.jsx
import React, { useEffect, useMemo, useState } from "react";
import { FaEdit, FaFilePdf, FaFileExcel } from "react-icons/fa";
import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";
import * as XLSX from "xlsx";

const API_BASE = "http://localhost:4000";

const getStatusColor = (status) => {
  switch (status) {
    case "Excellent": return "bg-green-100 text-green-700";
    case "Good":      return "bg-blue-100 text-blue-700";
    case "Average":   return "bg-yellow-100 text-yellow-700";
    case "Weak":      return "bg-red-100 text-red-700";
    default:          return "bg-gray-100 text-gray-700";
  }
};

const Students = () => {
  const [students, setStudents] = useState([]);
  const [options, setOptions] = useState({ grades: [{id:"All", name:"All"}], subjects: [{id:"All", name:"All"}] });

  const [filters, setFilters] = useState({ grade: "All", subject: "All" }); // IDs أو "All"
  const [search, setSearch] = useState("");          // Search by Name
  const [searchStatus, setSearchStatus] = useState(""); // Search by Status

  const [loading, setLoading] = useState(false);
  const [editingStudent, setEditingStudent] = useState(null);
  const [modalData, setModalData] = useState({ status: "", note: "" });

  const today = useMemo(() =>
    new Date().toLocaleDateString("en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric" }),
  []);

  // جلب الفلاتر من DB (classes/subjects)
  useEffect(() => {
    (async () => {
      try {
        const res = await fetch(`${API_BASE}/api/filters`);
        const data = await res.json();
        setOptions({
          grades:   data.grades   || [{ id: "All", name: "All" }],
          subjects: data.subjects || [{ id: "All", name: "All" }],
        });
      } catch (e) {
        console.error("filters error", e);
      }
    })();
  }, []);

  // جلب اللستة عند تغيير الفلاتر/البحث
  useEffect(() => {
    (async () => {
      setLoading(true);
      try {
        const qs = new URLSearchParams({
          grade:  filters.grade,
          subject: filters.subject,
          q:      search,
          status: searchStatus,
        });
        const res = await fetch(`${API_BASE}/api/students?` + qs.toString());
        const data = await res.json();
        setStudents(Array.isArray(data) ? data : []);
      } catch (e) {
        console.error("list error", e);
      } finally {
        setLoading(false);
      }
    })();
  }, [filters, search, searchStatus]);

  const handleEditClick = (student) => {
    setEditingStudent(student);
    setModalData({ status: student.status, note: student.note || "" });
  };

  const handleSaveEdit = async () => {
    try {
      const res = await fetch(`${API_BASE}/api/students/${editingStudent.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: modalData.status, note: modalData.note }),
      });
      if (!res.ok) throw new Error("update failed");
      const updated = await res.json();
      setStudents((prev) => prev.map((s) => (s.id === updated.id ? updated : s)));
      setEditingStudent(null);
    } catch (e) {
      console.error(e);
      alert("Update failed");
    }
  };

  const exportPDF = () => {
    const doc = new jsPDF();
    doc.text("Student Academic Overview", 14, 10);
    autoTable(doc, {
      startY: 20,
      head: [["Full Name", "Status", "Note", "Grade", "Subject"]],
      body: students.map((s) => [s.name, s.status, s.note || "", s.grade, s.subject]),
    });
    doc.save("students.pdf");
  };

  const exportExcel = () => {
    const worksheet = XLSX.utils.json_to_sheet(
      students.map(({ name, status, note, grade, subject }) => ({
        Name: name, Status: status, Note: note || "", Grade: grade, Subject: subject,
      }))
    );
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Students");
    XLSX.writeFile(workbook, "students.xlsx");
  };

  return (
    <div className="p-6 bg-[#F9FAFB] min-h-screen">
      <h2 className="text-xl font-semibold text-gray-800 mb-1">Student Academic Overview</h2>
      <p className="text-sm text-gray-500 mb-4">Today: {today}</p>

      {/* Export Buttons */}
      <div className="text-sm flex gap-3 mb-4">
        <button onClick={exportPDF} className="flex items-center gap-2 px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-sm rounded">
          <FaFilePdf /> Export PDF
        </button>
        <button onClick={exportExcel} className="flex items-center gap-2 px-4 py-2 bg-green-600 hover:bg-green-700 text-white text-sm rounded">
          <FaFileExcel /> Export Excel
        </button>
      </div>

      {/* Filters (Grades/Subjects من DB) */}
      <div className="bg-white rounded-xl shadow p-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 mb-6">
        <div>
          <label className="text-sm font-medium text-gray-600 mb-1 block">Grade</label>
          <select
            onChange={(e) => setFilters({ ...filters, grade: e.target.value })}
            value={filters.grade}
            className="w-full px-4 py-2 border rounded-md bg-gray-100 text-sm"
          >
            {options.grades.map((g) => (<option key={g.id} value={g.id}>{g.name}</option>))}
          </select>
        </div>

        <div>
          <label className="text-sm font-medium text-gray-600 mb-1 block">Subject</label>
          <select
            onChange={(e) => setFilters({ ...filters, subject: e.target.value })}
            value={filters.subject}
            className="w-full px-4 py-2 border rounded-md bg-gray-100 text-sm"
          >
            {options.subjects.map((s) => (<option key={s.id} value={s.id}>{s.name}</option>))}
          </select>
        </div>

        {/* Search by Name (بنفس المكان تحت الفلاتر) */}
        <div>
          <label className="text-sm font-medium text-gray-600 mb-1 block">Search by Name</label>
          <input
            type="text"
            placeholder="Type student name..."
            className="w-full px-4 py-2 border rounded-md bg-gray-100 text-sm"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        <div className="sm:col-span-2">
          <label className="text-sm font-medium text-gray-600 mb-1 block">Search by Status</label>
          <input
            type="text"
            placeholder="Type status (e.g., Excellent)"
            className="w-full px-4 py-2 border rounded-md bg-gray-100 text-sm"
            value={searchStatus}
            onChange={(e) => setSearchStatus(e.target.value)}
          />
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl shadow overflow-x-auto">
        <table className="min-w-full text-sm text-gray-700">
          <thead>
            <tr className="border-b bg-blue-50">
              <th className="text-left px-6 py-4 font-semibold">Full Name</th>
              <th className="text-left px-6 py-4 font-semibold">Academic Status</th>
              <th className="text-left px-6 py-4 font-semibold">Notes</th>
              <th className="text-left px-6 py-4 font-semibold">Grade</th>
              <th className="text-left px-6 py-4 font-semibold">Subject</th>
              <th className="px-4 py-4 w-12"></th>
            </tr>
          </thead>
          <tbody>
            {loading && (
              <tr><td colSpan={6} className="px-6 py-4 text-gray-500">Loading...</td></tr>
            )}
            {!loading && students.length === 0 && (
              <tr><td colSpan={6} className="px-6 py-4 text-gray-500">No results.</td></tr>
            )}
            {!loading && students.map((student) => (
              <tr key={student.id} className="border-b hover:bg-gray-50">
                <td className="px-6 py-4">{student.name}</td>
                <td className="px-6 py-4">
                  <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(student.status)}`}>
                    {student.status}
                  </span>
                </td>
                <td className="px-6 py-4">{student.note}</td>
                <td className="px-6 py-4">{student.grade}</td>
                <td className="px-6 py-4">{student.subject}</td>
                <td
                  className="px-4 py-4 text-gray-400 hover:text-gray-600 cursor-pointer"
                  onClick={() => handleEditClick(student)}
                >
                  <FaEdit />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Modal لتعديل Status/Note */}
      {editingStudent && (
        <div className="fixed inset-0 bg-black bg-opacity-30 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <h3 className="text-lg font-semibold mb-4">Edit Student</h3>

            <label className="block mb-2 text-sm font-medium">Status</label>
            <select
              className="w-full mb-4 px-4 py-2 border rounded-md bg-gray-100"
              value={modalData.status}
              onChange={(e) => setModalData({ ...modalData, status: e.target.value })}
            >
              <option>Excellent</option>
              <option>Good</option>
              <option>Average</option>
              <option>Weak</option>
            </select>

            <label className="block mb-2 text-sm font-medium">Note</label>
            <textarea
              className="w-full mb-4 px-4 py-2 border rounded-md bg-gray-100"
              value={modalData.note}
              onChange={(e) => setModalData({ ...modalData, note: e.target.value })}
            ></textarea>

            <div className="flex justify-end gap-2">
              <button onClick={() => setEditingStudent(null)} className="px-4 py-2 bg-gray-300 rounded hover:bg-gray-400">
                Cancel
              </button>
              <button onClick={handleSaveEdit} className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
                Save
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Students;
