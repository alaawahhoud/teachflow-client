import React, { useState } from "react";
import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";
import * as XLSX from "xlsx";
import { motion } from "framer-motion";
import { FaFilePdf, FaFileExcel, FaPlus } from "react-icons/fa";
import { useNavigate } from "react-router-dom";

const Exams = () => {
  const navigate = useNavigate();
  const today = new Date().toISOString().split("T")[0];

  const subjectOptions = [
  "Math",
  "Science",
  "English",
  "Arabic",
  "French",
  "History",
  "Geography",
  "Civics",
  "Physics",
  "Chemistry",
  "Biology",
  "Computer",
  "Philosophy",
  "Economics",
  "Sociology",
  "Religion",
  "Art",
  "Music",
  "Physical Education",
  "Technology",
  "Business",
  "Statistics",
  "Environmental Science",
  "Drama",
];
  const examTypeOptions = ["Midterm", "Final", "Quiz", "Essay"];
  const gradeOptions = ["KG1", "KG2", ...Array.from({ length: 12 }, (_, i) => `Grade ${i + 1}`)];
  const durationOptions = ["1 hour", "1.5 hours", "2 hours", "2.5 hours", "3 hours", "3.5 hours", "4 hours"];
  const statusOptions = ["Draft", "Done Not Corrected", "Not Done Yet", "Correction in Progress"];

const [filters, setFilters] = useState({
  grade: "All",
  subject: "All",
  type: "All",
  status: "All",
  date: "All",
});


  const [exams, setExams] = useState([]);

  const filteredExams = exams.filter((exam) => {
    const { grade, subject, type, status, date } = filters;
    return (
      (grade === "All" || exam.grade === grade) &&
      (subject === "All" || exam.subject === subject) &&
      (type === "All" || exam.type === type) &&
      (status === "All" || exam.status === status) &&
      (date === "All" || exam.date === date)
    );
  });

  const getStatusStyle = (status) => {
    switch (status) {
      case "Draft": return "bg-gray-200 text-gray-800 ring-1 ring-gray-300";
      case "Done Not Corrected": return "bg-yellow-100 text-yellow-800 ring-1 ring-yellow-300";
      case "Not Done Yet": return "bg-red-100 text-red-700 ring-1 ring-red-300";
      case "Correction in Progress": return "bg-orange-100 text-orange-700 ring-1 ring-orange-300";
      default: return "bg-gray-100 text-gray-600";
    }
  };

  const updateExam = (id, key, value) => {
    setExams((prev) => prev.map((exam) =>
      exam.id === id ? { ...exam, [key]: value } : exam
    ));
  };
const addExam = () => {
  const newExam = {
    id: exams.length + 1,
    title: "",
    subject: subjectOptions[0],
    type: examTypeOptions[0],
    grade: gradeOptions[0],
    date: filters.date === "All" ? today : filters.date,
    time: "08:00",
    duration: durationOptions[0],
    status: "Draft",
  };
  setExams([...exams, newExam]);

  // 👇 Reset filters to "All" so the new exam always shows
  setFilters({
    grade: "All",
    subject: "All",
    type: "All",
    status: "All",
    date: "All",
  });
};

  const exportPDF = () => {
    const doc = new jsPDF();
    doc.setFont("helvetica", "bold");
    doc.setFontSize(16);
    doc.text("Exams Report", 14, 20);
    autoTable(doc, {
      startY: 30,
      head: [["Title", "Subject", "Type", "Grade", "Date", "Time", "Duration", "Status"]],
      body: exams.map((e) => [
        e.title, e.subject, e.type, e.grade, e.date, e.time, e.duration, e.status,
      ]),
      styles: { fontSize: 10, cellPadding: 3 },
      headStyles: { fillColor: [52, 152, 219], textColor: 255, halign: "center" },
      bodyStyles: { halign: "center" },
      theme: "striped",
    });
    doc.save("exams_report.pdf");
  };

  const exportExcel = () => {
    const worksheet = XLSX.utils.json_to_sheet(exams);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Exams");
    const excelData = XLSX.write(workbook, { bookType: "xlsx", type: "binary" });
    const s2ab = (s) => {
      const buf = new ArrayBuffer(s.length);
      const view = new Uint8Array(buf);
      for (let i = 0; i < s.length; i++) view[i] = s.charCodeAt(i) & 0xff;
      return buf;
    };
    const blob = new Blob([s2ab(excelData)], { type: "application/octet-stream" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "exams_report.xlsx";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <div className="p-6 md:p-8 bg-[#F9FAFB] min-h-screen text-gray-800">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
        <h2 className="text-2xl font-bold">Exams & Correction Panel</h2>
        <div className="flex gap-2">
          <div className="relative group">
  <button className="flex items-center gap-1 bg-gray-200 text-gray-800 px-3 py-2 rounded text-sm hover:bg-gray-300">
    Export ▼
  </button>
  <div className="absolute z-20 hidden group-hover:block mt-1 w-32 bg-white border shadow rounded">
    <button onClick={exportPDF} className="w-full px-4 py-2 text-left text-sm hover:bg-gray-100">PDF</button>
    <button onClick={exportExcel} className="w-full px-4 py-2 text-left text-sm hover:bg-gray-100">Excel</button>
  </div>
</div>
          <button onClick={addExam} className="flex items-center gap-1 bg-blue-600 text-white px-3 py-2 rounded text-sm hover:bg-blue-700">
            <FaPlus /> Add Exam
          </button>
        </div>
      </div>
<div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 mb-6">
  {[
    { label: "Grade", key: "grade", options: ["All", ...gradeOptions] },
    { label: "Subject", key: "subject", options: ["All", ...subjectOptions] },
    { label: "Type", key: "type", options: ["All", ...examTypeOptions] },
    { label: "Status", key: "status", options: ["All", ...statusOptions] }
  ].map(({ label, key, options }) => (
    <div key={key}>
      <label className="block text-sm font-medium mb-1">{label}</label>
      <select
        className="w-full bg-white border border-gray-300 rounded px-4 py-2 text-sm shadow-sm"
        value={filters[key]}
        onChange={(e) => setFilters({ ...filters, [key]: e.target.value })}
      >
        {options.map((val) => (
          <option key={val}>{val}</option>
        ))}
      </select>
    </div>
  ))}
  <div>
    <label className="block text-sm font-medium mb-1">Date</label>
    <input
      type="date"
      className="w-full bg-white border border-gray-300 rounded px-4 py-2 text-sm shadow-sm"
      value={filters.date}
      onChange={(e) => setFilters({ ...filters, date: e.target.value })}
    />
  </div>
</div>
      <motion.div 
        className="overflow-x-auto bg-white shadow rounded-xl max-h-[70vh] overflow-y-auto"
        initial={{ opacity: 0, y: 20 }} 
        animate={{ opacity: 1, y: 0 }} 
        transition={{ duration: 0.5 }}
      >
        <table className="table-auto w-full text-sm">
          <thead className="bg-gray-50 sticky top-0 z-10">
            <tr className="text-left border-b">
              <th className="px-4 py-3">Subject</th>
              <th className="px-4 py-3">Exam Title</th>
              <th className="px-4 py-3">Exam Type</th>
              <th className="px-4 py-3">Grade</th>
              <th className="px-4 py-3">Date</th>
              <th className="px-4 py-3">Time</th>
              <th className="px-4 py-3">Duration</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredExams.map((exam) => (
              <tr key={exam.id} className="border-b">
                <td className="px-4 py-2">
                  <select
  value={exam.subject}
  onChange={(e) => updateExam(exam.id, "subject", e.target.value)}
  className="border px-2 py-1 rounded text-xs w-full"
>
  {subjectOptions.map((subj) => (
    <option key={subj} value={subj}>
      {subj}
    </option>
  ))}
</select>

                  <datalist id={`subjects-${exam.id}`}>
                    {subjectOptions.map((subj) => (
                      <option key={subj} value={subj} />
                    ))}
                  </datalist>
                </td>
                <td className="px-4 py-2">
                  <input type="text" value={exam.title} onChange={(e) => updateExam(exam.id, "title", e.target.value)} className="border px-2 py-1 rounded text-xs w-full" />
                </td>
                <td className="px-4 py-2">
                  <select value={exam.type} onChange={(e) => updateExam(exam.id, "type", e.target.value)} className="border px-2 py-1 rounded text-xs w-full">
                    {examTypeOptions.map((type) => (
                      <option key={type}>{type}</option>
                    ))}
                  </select>
                </td>
                <td className="px-4 py-2">
                  <select value={exam.grade} onChange={(e) => updateExam(exam.id, "grade", e.target.value)} className="border px-2 py-1 rounded text-xs w-full">
                    {gradeOptions.map((grade) => (
                      <option key={grade}>{grade}</option>
                    ))}
                  </select>
                </td>
                <td className="px-4 py-2">
                  <input type="date" value={exam.date} onChange={(e) => updateExam(exam.id, "date", e.target.value)} className="border px-2 py-1 rounded text-xs w-full" />
                </td>
                <td className="px-4 py-2">
                  <input type="time" value={exam.time} onChange={(e) => updateExam(exam.id, "time", e.target.value)} className="border px-2 py-1 rounded text-xs w-full" />
                </td>
                <td className="px-4 py-2">
                  <select value={exam.duration} onChange={(e) => updateExam(exam.id, "duration", e.target.value)} className="border px-2 py-1 rounded text-xs w-full">
                    {durationOptions.map((dur) => (
                      <option key={dur}>{dur}</option>
                    ))}
                  </select>
                </td>
                <td className="px-4 py-2">
                  <select value={exam.status} onChange={(e) => updateExam(exam.id, "status", e.target.value)} className={`px-2 py-1 rounded text-xs font-medium w-full ${getStatusStyle(exam.status)}`}>
                    {statusOptions.map((s) => (
                      <option key={s}>{s}</option>
                    ))}
                  </select>
                </td>
                <td className="px-4 py-2 whitespace-nowrap space-x-2">
                  <button onClick={() => navigate(`/exam/${exam.id}/view`)} className="border border-blue-500 text-blue-500 px-3 py-1 rounded text-xs hover:bg-blue-50">View</button>
                  <button onClick={() => navigate(`/exam/${exam.id}/message`)} className="border border-yellow-500 text-yellow-600 px-3 py-1 rounded text-xs hover:bg-yellow-50">Message</button>
                  <button onClick={() => navigate(`/exam/${exam.id}/correction`)} className="border border-green-500 text-green-600 px-3 py-1 rounded text-xs hover:bg-green-50">Correct</button>
                </td>
              </tr>
            ))}
          </tbody>
          {filteredExams.length === 0 && (
  <tr>
    <td colSpan="9" className="text-center py-6 text-gray-500">
      No exams match the selected filters.
    </td>
  </tr>
)}
        </table>
      </motion.div>
      <div className="flex justify-end mt-6">
  <button
    onClick={() => console.log("Saving exams...", exams)}
    className="bg-green-600 text-white px-6 py-2 rounded hover:bg-green-700 transition"
  >
    Save Exam
  </button>
</div>

    </div>
  );
};

export default Exams;
