import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

const API_BASE =
  (typeof import.meta !== "undefined" && import.meta.env && import.meta.env.VITE_API_URL) ||
  process.env.REACT_APP_API_URL ||
  "http://localhost:4000/api";

export default function ResetPassword() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [loading, setLoading] = useState(true);
  const [error, setError]   = useState("");
  const [ok, setOk]         = useState("");

  const [fullName, setFullName] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm]   = useState("");

  useEffect(() => {
    let ignore = false;
    (async () => {
      setLoading(true); setError("");
      try {
        const res = await fetch(`${API_BASE}/users/${id}`);
        const data = await res.json();
        if (!res.ok) throw new Error(data?.message || `Load failed (HTTP ${res.status})`);
        if (ignore) return;
        setFullName(data.name || "");
        setUsername(data.username || "");
      } catch (e) {
        if (!ignore) setError(e.message || "Failed to load user");
      } finally {
        if (!ignore) setLoading(false);
      }
    })();
    return () => { ignore = true; };
  }, [id]);

  const handleSave = async (e) => {
    e?.preventDefault?.();
    setError(""); setOk("");

    if (!username.trim()) return setError("Username is required");
    if (password || confirm) {
      if (password.length < 6) return setError("Password must be at least 6 characters");
      if (password !== confirm) return setError("Passwords do not match");
    }

    try {
      const payload = { username: username.trim() };
      if (password) payload.password = password;

      const res = await fetch(`${API_BASE}/users/${id}/credentials`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.message || `Save failed (HTTP ${res.status})`);

      setOk("Saved!");
      setTimeout(() => navigate("/users"), 700);
    } catch (e) {
      setError(e.message || "Save failed");
    }
  };

  if (loading) return <div className="p-6">Loading…</div>;

  return (
    <div className="p-6 md:p-8 bg-[#F9FAFB] min-h-screen text-gray-800">
      <div className="bg-white p-6 md:p-8 rounded-xl shadow max-w-xl mx-auto">
        <div className="mb-6 border-b pb-4">
          <h2 className="text-2xl font-bold text-gray-800">Reset Credentials</h2>
          <p className="text-sm text-gray-500 mt-1">{fullName ? `User: ${fullName}` : ""}</p>
        </div>

        {error && <div className="mb-4 rounded-md bg-red-50 border border-red-200 px-4 py-3 text-sm text-red-700">{error}</div>}
        {ok && <div className="mb-4 rounded-md bg-green-50 border border-green-200 px-4 py-3 text-sm text-green-800">{ok}</div>}

        <form onSubmit={handleSave} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1">Username</label>
            <input
              className="w-full border px-4 py-2 rounded"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Username"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">New Password</label>
            <input
              type="password"
              className="w-full border px-4 py-2 rounded"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Leave blank to keep current"
            />
            <p className="text-xs text-gray-500 mt-1">Minimum 6 characters.</p>
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Confirm Password</label>
            <input
              type="password"
              className="w-full border px-4 py-2 rounded"
              value={confirm}
              onChange={(e) => setConfirm(e.target.value)}
              placeholder="Repeat new password"
            />
          </div>

          <div className="pt-2 flex items-center justify-end gap-2">
            <button type="button" onClick={() => navigate(-1)} className="border px-4 py-2 rounded bg-white hover:bg-gray-50">
              Cancel
            </button>
            <button type="submit" className="bg-blue-600 text-white px-6 py-2 rounded-md shadow hover:bg-blue-700">
              Save
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
